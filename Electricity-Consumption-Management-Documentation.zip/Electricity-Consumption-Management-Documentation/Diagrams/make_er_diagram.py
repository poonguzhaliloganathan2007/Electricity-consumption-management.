"""Generates ER_Diagram.dot (Chen notation, fixed positions) from the schema in schema.sql.
Render with:  neato -n -Tpng ER_Diagram.dot -o ER_Diagram.png
Edit entity/attribute lists below (or edit ER_Diagram.dot directly) and re-run."""
import math

ENT = {  # name: (x, y, attributes[(label, kind)])   kind: pk | fk | n
 "CONSUMERS": (180, 330, [("id","pk"),("consumer_number","uk"),("full_name","n"),("address","n"),("connection_type","n")]),
 "READINGS":  (780, 330, [("id","pk"),("consumer_id","fk"),("reading_date","n"),("previous_reading","n"),("current_reading","n"),("units","n")]),
 "BILLS":     (480,-170, [("id","pk"),("consumer_id","fk"),("reading_id","fk"),("bill_month","n"),("units","n"),("amount","n"),("payment_status","n")]),
}
# angle ranges (degrees, 0=east, 90=north) used to fan attributes around each entity
ARC = {"CONSUMERS": (35, 245), "READINGS": (-45, 145), "BILLS": (200, 340)}
RADIUS = {"CONSUMERS": 150, "READINGS": 150, "BILLS": 190}
REL = [  # name, x, y, entity A, card A, entity B, card B
 ("has",       480, 330, "CONSUMERS", "1", "READINGS", "N"),
 ("is billed", 180,  40, "CONSUMERS", "1", "BILLS",    "N"),
 ("generates", 780,  40, "READINGS",  "1", "BILLS",    "N"),
]
out = ["graph ER {", "  graph [bgcolor=white, splines=line, outputorder=edgesfirst];",
       "  node [fontname=\"Arial\", fontsize=13];", "  edge [fontname=\"Arial\", fontsize=13, color=\"#333333\"];"]
for e,(x,y,attrs) in ENT.items():
    out.append(f"  {e} [shape=box, style=\"filled,bold\", fillcolor=\"#D9E2F3\", width=1.5, height=0.55, fontsize=15, pos=\"{x},{y}!\"];")
    a0,a1 = ARC[e]; n=len(attrs)
    for i,(lab,kind) in enumerate(attrs):
        ang = math.radians(a0 + (a1-a0)*(i/(n-1) if n>1 else .5))
        ax, ay = x + RADIUS[e]*math.cos(ang)*1.55, y + RADIUS[e]*math.sin(ang)
        nid = f"{e}_{lab}"
        text = f"<<U>{lab}</U>>" if kind=="pk" else (f"<<I>{lab}</I>>" if kind=="fk" else f"\"{lab}\"")
        extra = ", peripheries=2" if False else ""
        style = "filled,dashed" if kind=="fk" else "filled"
        out.append(f"  {nid} [shape=ellipse, style=\"{style}\", fillcolor=\"#FFFFFF\", label={text}, pos=\"{ax:.0f},{ay:.0f}!\"];")
        out.append(f"  {e} -- {nid};")
for name,x,y,a,ca,b,cb in REL:
    rid = "R_"+name.replace(" ","_")
    out.append(f"  {rid} [shape=diamond, style=filled, fillcolor=\"#FFF2CC\", label=\"{name}\", width=1.5, height=0.9, pos=\"{x},{y}!\"];")
    out.append(f"  {a} -- {rid} [label=\"{ca}\", fontsize=14];")
    out.append(f"  {rid} -- {b} [label=\"{cb}\", fontsize=14];")
out.append("}")
open("ER_Diagram.dot","w").write("\n".join(out))
