"""Draws Use_Case_Diagram.png with Matplotlib (UML use case notation). Keep in sync with Use_Case_Diagram.puml."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle, Circle

A = ["Login", "View Dashboard", "Add Consumer", "View Consumers",
     "Update Consumer\n(REST API only, no UI form)", "Delete Consumer", "View Monthly Usage"]
B = ["Validate Reading\n(current >= previous)", "Add Meter Reading", "Generate Bill\n(5.00 per unit + 30.00)",
     "View Reading History", "View Bills", "Mark Bill as Paid", "Download CSV Report"]
B_ADMIN = {1, 3, 4, 5, 6}          # use cases directly linked to Admin in column B
XA, XB, W, H, STEP = 5.6, 9.4, 3.3, 1.0, 1.9
YA = [12.6 - STEP*i for i in range(len(A))]
YB = [y - STEP/2 for y in YA]

fig, ax = plt.subplots(figsize=(10.5, 12.5))
ax.set_xlim(0, 13.6); ax.set_ylim(-1.2, 14.4); ax.axis("off")
ax.add_patch(Rectangle((3.2, -0.4), 8.6, 13.5, fill=False, lw=1.8, ec="black"))
ax.text(7.5, 14.0, "Electricity Consumption Management and\nEnergy Usage Analysis System", ha="center", va="center", fontsize=11, weight="bold")

def uc(x, y, label):
    ax.add_patch(Ellipse((x, y), W, H, fc="#EAF1FB", ec="black", lw=1.2))
    ax.text(x, y, label, ha="center", va="center", fontsize=8.6)

def actor(x, y, label):
    ax.add_patch(Circle((x, y+1.05), 0.28, fc="white", ec="black", lw=1.5))
    ax.plot([x, x], [y+0.77, y-0.2], color="black", lw=1.5)
    ax.plot([x-0.55, x+0.55], [y+0.5, y+0.5], color="black", lw=1.5)
    ax.plot([x, x-0.45], [y-0.2, y-0.95], color="black", lw=1.5)
    ax.plot([x, x+0.45], [y-0.2, y-0.95], color="black", lw=1.5)
    ax.text(x, y-1.35, label, ha="center", va="center", fontsize=10, weight="bold")

for y, l in zip(YA, A): uc(XA, y, l)
for y, l in zip(YB, B): uc(XB, y, l)

# Admin (left) -> bus line -> use cases
AX, AY, BUS = 1.4, 6.6, 3.6
ax.plot([AX+0.55, BUS], [AY+0.5, AY+0.5], color="black", lw=1.2)
targets = [(XA-W/2, y) for y in YA] + [(XB-W/2, YB[i]) for i in B_ADMIN]
ys = [t[1] for t in targets]
ax.plot([BUS, BUS], [min(ys), max(ys)], color="black", lw=1.2)
for (x, y) in targets: ax.plot([BUS, x], [y, y], color="black", lw=1.2)
actor(AX, AY, "Admin")

# Python actor (right) -> Download CSV Report
PX = 12.8
actor(PX, YB[6]-0.1, "Python Analysis\nScript")
ax.plot([XB+W/2, PX-0.55], [YB[6], YB[6]], color="black", lw=1.2)

# <<include>> dashed arrows from Add Meter Reading (B1)
def include(y_from, y_to, tag_dx=0.15):
    ax.annotate("", xy=(XB, y_to + (H/2 if y_to < y_from else -H/2)), xytext=(XB, y_from + (-H/2 if y_to < y_from else H/2)),
                arrowprops=dict(arrowstyle="-|>", linestyle="--", color="black", lw=1.2))
    ax.text(XB+0.15, (y_from+y_to)/2, "<<include>>", fontsize=8.5, style="italic", va="center", ha="left",
            bbox=dict(fc="white", ec="none", pad=0.5))
include(YB[1], YB[0]); include(YB[1], YB[2])

ax.text(5.4, -0.95, "Primary actor: Admin (demo login). Secondary actor: Python script (CSV endpoint).",
        ha="center", fontsize=8.5, style="italic")
fig.savefig("Use_Case_Diagram.png", dpi=170, bbox_inches="tight", facecolor="white")
