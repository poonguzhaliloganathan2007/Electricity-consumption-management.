-- =====================================================================
-- 03_queries.sql  --  SQL operations for electricity_db
-- PART A : statements that the Java application really executes
--          (taken from ElectricityApplication.java; ? = JDBC parameter).
-- PART B : additional example queries written for the documentation
--          (NOT executed by the application) - use them for the DBMS record.
-- =====================================================================
USE electricity_db;

-- ------------------------------- PART A -------------------------------
-- A1 INSERT (POST /api/consumers)
INSERT INTO consumers (consumer_number, full_name, address, connection_type) VALUES (?, ?, ?, ?);
-- A2 SELECT (GET /api/consumers)
SELECT * FROM consumers ORDER BY id DESC;
-- A3 UPDATE (PUT /api/consumers/{id})
UPDATE consumers SET consumer_number=?, full_name=?, address=?, connection_type=? WHERE id=?;
-- A4 DELETE (DELETE /api/consumers/{id}) - three statements, child tables first
DELETE FROM bills WHERE consumer_id=?;
DELETE FROM readings WHERE consumer_id=?;
DELETE FROM consumers WHERE id=?;
-- A5 INSERT reading + bill (POST /api/readings)
INSERT INTO readings (consumer_id, reading_date, previous_reading, current_reading, units) VALUES (?, ?, ?, ?, ?);
SELECT MAX(id) FROM readings WHERE consumer_id=?;
INSERT INTO bills (consumer_id, reading_id, bill_month, units, amount, payment_status) VALUES (?, ?, ?, ?, ?, 'Pending');
-- A6 SELECT with JOIN (GET /api/readings and GET /api/bills)
SELECT r.*, c.consumer_number, c.full_name FROM readings r JOIN consumers c ON r.consumer_id=c.id ORDER BY r.id DESC;
SELECT b.*, c.consumer_number, c.full_name FROM bills b JOIN consumers c ON b.consumer_id=c.id ORDER BY b.id DESC;
-- A7 UPDATE payment status (PUT /api/bills/{id}/pay)
UPDATE bills SET payment_status='Paid' WHERE id=?;
-- A8 Dashboard aggregates (GET /api/dashboard)
SELECT COUNT(*) FROM consumers;
SELECT COUNT(*) FROM readings;
SELECT COALESCE(SUM(units),0) FROM readings;
SELECT COALESCE(SUM(amount),0) FROM bills;
SELECT COUNT(*) FROM bills WHERE payment_status='Pending';
-- A9 Monthly analysis (GET /api/analysis/monthly)
SELECT bill_month, SUM(units) AS total_units, SUM(amount) AS total_amount FROM bills GROUP BY bill_month ORDER BY bill_month;
-- A10 CSV report (GET /api/reports/consumption.csv)
SELECT c.consumer_number, c.full_name, r.reading_date, r.previous_reading, r.current_reading, r.units
FROM readings r JOIN consumers c ON r.consumer_id=c.id ORDER BY r.reading_date;

-- ------------------------------- PART B -------------------------------
-- B1 Consumer-wise total consumption and total billed amount
SELECT c.consumer_number, c.full_name, SUM(r.units) AS total_units, SUM(b.amount) AS total_amount
FROM consumers c JOIN readings r ON r.consumer_id = c.id JOIN bills b ON b.reading_id = r.id
GROUP BY c.id, c.consumer_number, c.full_name ORDER BY total_units DESC;
-- B2 Top 5 high-consumption consumers
SELECT c.consumer_number, c.full_name, SUM(r.units) AS total_units
FROM consumers c JOIN readings r ON r.consumer_id = c.id
GROUP BY c.id, c.consumer_number, c.full_name ORDER BY total_units DESC LIMIT 5;
-- B3 Pending bills with consumer details
SELECT c.consumer_number, c.full_name, b.bill_month, b.units, b.amount
FROM bills b JOIN consumers c ON b.consumer_id = c.id WHERE b.payment_status = 'Pending' ORDER BY b.bill_month;
-- B4 Paid versus pending amount
SELECT payment_status, COUNT(*) AS bill_count, SUM(amount) AS total_amount FROM bills GROUP BY payment_status;
-- B5 Consumption by connection type
SELECT c.connection_type, SUM(r.units) AS total_units
FROM consumers c JOIN readings r ON r.consumer_id = c.id GROUP BY c.connection_type;
-- B6 Consumers without any reading (LEFT JOIN)
SELECT c.consumer_number, c.full_name FROM consumers c LEFT JOIN readings r ON r.consumer_id = c.id WHERE r.id IS NULL;
-- B7 Consistency check: stored units must equal current - previous (expected: 0 rows)
SELECT id, previous_reading, current_reading, units FROM readings WHERE units <> current_reading - previous_reading;
-- B8 Consistency check: demo tariff amount (expected: 0 rows)
SELECT id, units, amount FROM bills WHERE amount <> units * 5.00 + 30.00;
