-- =====================================================================
-- 02_sample_data.sql  --  ILLUSTRATIVE SAMPLE DATA (NOT REAL CONSUMER DATA)
-- Optional. Run only on a TEST copy of electricity_db to try the queries and the Python analysis.
-- Rows follow the application rules: units = current - previous; amount = 5.00 * units + 30.00 (demo tariff).
-- WARNING: this inserts explicit ids, so run it only on empty tables.
-- =====================================================================
USE electricity_db;

INSERT INTO consumers (id, consumer_number, full_name, address, connection_type) VALUES
(1, 'CN-1001', 'Sample Consumer 1', 'Sample Street 1', 'Domestic'),
(2, 'CN-1002', 'Sample Consumer 2', 'Sample Street 2', 'Domestic'),
(3, 'CN-1003', 'Sample Consumer 3', 'Sample Street 3', 'Domestic'),
(4, 'CN-1004', 'Sample Consumer 4', 'Sample Market Road 4', 'Commercial'),
(5, 'CN-1005', 'Sample Consumer 5', 'Sample Market Road 5', 'Commercial'),
(6, 'CN-1006', 'Sample Consumer 6', 'Sample Industrial Estate 6', 'Industrial');

INSERT INTO readings (id, consumer_id, reading_date, previous_reading, current_reading, units) VALUES
(1, 1, '2026-08-05', 1200, 1342, 142),
(2, 1, '2026-09-05', 1342, 1500, 158),
(3, 1, '2026-10-05', 1500, 1671, 171),
(4, 2, '2026-08-05', 800, 896, 96),
(5, 2, '2026-09-05', 896, 1006, 110),
(6, 2, '2026-10-05', 1006, 1110, 104),
(7, 3, '2026-08-05', 2500, 2730, 230),
(8, 3, '2026-09-05', 2730, 2992, 262),
(9, 3, '2026-10-05', 2992, 3240, 248),
(10, 4, '2026-08-05', 9000, 9455, 455),
(11, 4, '2026-09-05', 9455, 9967, 512),
(12, 4, '2026-10-05', 9967, 10465, 498),
(13, 5, '2026-08-05', 12000, 12610, 610),
(14, 5, '2026-09-05', 12610, 13195, 585),
(15, 5, '2026-10-05', 13195, 13835, 640),
(16, 6, '2026-08-05', 40000, 41850, 1850),
(17, 6, '2026-09-05', 41850, 43950, 2100),
(18, 6, '2026-10-05', 43950, 45925, 1975);

INSERT INTO bills (id, consumer_id, reading_id, bill_month, units, amount, payment_status) VALUES
(1, 1, 1, '2026-08', 142, 740.00, 'Paid'),
(2, 1, 2, '2026-09', 158, 820.00, 'Paid'),
(3, 1, 3, '2026-10', 171, 885.00, 'Pending'),
(4, 2, 4, '2026-08', 96, 510.00, 'Paid'),
(5, 2, 5, '2026-09', 110, 580.00, 'Pending'),
(6, 2, 6, '2026-10', 104, 550.00, 'Pending'),
(7, 3, 7, '2026-08', 230, 1180.00, 'Paid'),
(8, 3, 8, '2026-09', 262, 1340.00, 'Paid'),
(9, 3, 9, '2026-10', 248, 1270.00, 'Paid'),
(10, 4, 10, '2026-08', 455, 2305.00, 'Paid'),
(11, 4, 11, '2026-09', 512, 2590.00, 'Paid'),
(12, 4, 12, '2026-10', 498, 2520.00, 'Pending'),
(13, 5, 13, '2026-08', 610, 3080.00, 'Paid'),
(14, 5, 14, '2026-09', 585, 2955.00, 'Pending'),
(15, 5, 15, '2026-10', 640, 3230.00, 'Pending'),
(16, 6, 16, '2026-08', 1850, 9280.00, 'Paid'),
(17, 6, 17, '2026-09', 2100, 10530.00, 'Paid'),
(18, 6, 18, '2026-10', 1975, 9905.00, 'Pending');
